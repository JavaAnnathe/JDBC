import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class DeleteEmployeeDetailsDemo {
	
	
public static void main(String args[]){  
		
		try{  
			
			Class.forName("com.mysql.cj.jdbc.Driver"); 

			Connection con=DriverManager.getConnection(  
			"jdbc:mysql://localhost:3306/emp","root","root"); 

		
		Statement stmt=con.createStatement();  
		
		String sql1 = "delete from employee " +  "where id = 700";
		String sql2 = "delete from employee " +  "where id = 715";
		stmt.executeUpdate(sql1);
		stmt.executeUpdate(sql2);
		
		
		System.out.println("deleted record from table...");
		con.close();  

		}catch(Exception e){
			e.printStackTrace();
		}  

		} 

}
