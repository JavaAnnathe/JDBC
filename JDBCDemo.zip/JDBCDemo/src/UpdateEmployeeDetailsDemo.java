import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class UpdateEmployeeDetailsDemo {
	
	
public static void main(String args[]){  
		
		try{  
			
			Class.forName("com.mysql.cj.jdbc.Driver"); 

			Connection con=DriverManager.getConnection(  
			"jdbc:mysql://localhost:3306/emp","root","root"); 

		//here gsat is database name, root is username and password  
		Statement stmt=con.createStatement();  
		
		String sql = "update employee set name='Rakesh Kumar' " + "where id = 700";
        stmt.executeUpdate(sql);
		
		
		System.out.println("updated records into the table...");
		con.close();  

		}catch(Exception e){
			e.printStackTrace();
		}  

		} 
	

}
