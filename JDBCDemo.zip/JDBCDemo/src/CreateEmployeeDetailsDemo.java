import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class CreateEmployeeDetailsDemo {
	
	
public static void main(String args[]){  
		
		try{  
		//Loading the driver	
		Class.forName("com.mysql.cj.jdbc.Driver"); 
		
		//Establish connection
		Connection con=DriverManager.getConnection(  
		"jdbc:mysql://localhost:3306/emp","root","root"); 

		//Creating statement
		Statement stmt=con.createStatement();  
		
		String sql = "insert into employee " +  "values (700, 'Rakesh', 'Developer', 20, 10000,10000)";
		
		//Execute query
		stmt.executeUpdate(sql);

		System.out.println("Inserted records into the table...");
		con.close();  

		}catch(Exception e){
			e.printStackTrace();
		}  

		} 


}
